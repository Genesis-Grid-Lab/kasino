#include "events/EventBus.h"
// Intentionally empty; header-only style for templates & specializations.
// (This file just helps IDEs see the target.)
