#include "gfx/Render2D.h"
#include "core/Factory.h"
#include "gfx/RenderCommand.h"
#include <glm/gtc/type_ptr.hpp>
#include <cstring>
#include "gfx/IShader.h"
#include "gfx/Camera2D.h"

#include <cstdio>

// ---------- Static storage ----------

Ref<IVertexArray> Render2D::s_vao;
Ref<IBuffer>      Render2D::s_vbo;
Ref<IBuffer>      Render2D::s_ibo;
Ref<IShader>      Render2D::s_shader;
Ref<ITexture2D>   Render2D::s_white;

std::vector<Render2D::QuadVertex> Render2D::s_cpu;
uint32_t Render2D::s_quadCount = 0;

Ref<ITexture2D> Render2D::s_texSlots[Render2D::MaxTexSlots] = {};
uint32_t        Render2D::s_texCount = 0;

glm::mat4 Render2D::s_viewProj(1.0f);

Render2D::Stats Render2D::s_stats{};
bool Render2D::s_ready = false;

// ---------- Public API ----------

bool Render2D::Initialize() {
  if (s_ready) return true;

  s_vao    = Factory::CreateVertexArray();
  s_vbo    = Factory::CreateBuffer(BufferType::Vertex);
  s_ibo    = Factory::CreateBuffer(BufferType::Index);
  s_shader = Factory::CreateShader("Data/Shaders/basic.glsl");

  std::string log;
  // if (!s_shader->CompileFromSource(VS, FS, &log)) {
  //   std::fprintf(stderr, "[Render2D] Shader error: %s\n", log.c_str());
  //   return false;
  // }

  // uTextures[0..15] -> texture units 0..15
  s_shader->Bind();
  int samplers[16]; for (int i=0;i<16;i++) samplers[i] = i;
  s_shader->SetIntArray("uTextures", samplers, 16);

  // Allocate CPU staging fixed to MaxVerts and GPU buffers
  s_cpu.clear();
  s_cpu.resize(MaxVerts);

  s_vbo->SetData(nullptr, sizeof(QuadVertex) * MaxVerts, /*dynamic*/true);

  // Build index buffer once (two triangles per quad)
  std::vector<uint32_t> indices(MaxIndices);
  uint32_t offset = 0;
  for (uint32_t i=0; i<MaxIndices; i += 6) {
    indices[i+0] = offset + 0;
    indices[i+1] = offset + 1;
    indices[i+2] = offset + 2;
    indices[i+3] = offset + 0;
    indices[i+4] = offset + 2;
    indices[i+5] = offset + 3;
    offset += 4;
  }
  s_ibo->SetData(indices.data(), indices.size() * sizeof(uint32_t), /*dynamic*/false);

  // VAO layout
  s_vao->Bind();
  s_vbo->Bind();
  s_ibo->Bind();
  // pos (2f)
  s_vao->EnableAttrib(0, 2, 0x1406/*GL_FLOAT*/, false, sizeof(QuadVertex), offsetof(QuadVertex, x));
  // color (4f)
  s_vao->EnableAttrib(1, 4, 0x1406/*GL_FLOAT*/, false, sizeof(QuadVertex), offsetof(QuadVertex, r));
  // uv (2f)
  s_vao->EnableAttrib(2, 2, 0x1406/*GL_FLOAT*/, false, sizeof(QuadVertex), offsetof(QuadVertex, u));
  // tex index (1f)
  s_vao->EnableAttrib(3, 1, 0x1406/*GL_FLOAT*/, false, sizeof(QuadVertex), offsetof(QuadVertex, texIndex));
  // tiling (1f)
  s_vao->EnableAttrib(4, 1, 0x1406/*GL_FLOAT*/, false, sizeof(QuadVertex), offsetof(QuadVertex, tiling));
  s_vao->Unbind();

  // 1x1 white texture in slot 0
  s_white = Factory::CreateTexture2D();
  const uint32_t white = 0xFFFFFFFFu;
  s_white->Create(1, 1, 4, &white);

  s_ready = true;
  ResetStats();
  startBatch();
  return true;
}

void Render2D::Shutdown() {
  // Flush any pending work
  flush();

  // Delete GL objects while context is still alive
  if (s_shader) {
    s_shader->Destroy();
    s_shader.reset();
  }
  // Buffers & textures can be reset; their destructors should also avoid GL or you can add Destroy() to them too.
  s_vao.reset();
  s_vbo.reset();
  s_ibo.reset();
  s_white.reset();

  s_cpu.clear();
  s_quadCount = 0;
  s_texCount  = 0;
  s_ready = false;
}

void Render2D::BeginScene(const glm::mat4& viewProj) {
  s_viewProj = viewProj;
  startBatch();
}

void Render2D::BeginScene(const Camera2D& cam) {
  BeginScene(cam.ViewProj());
}

void Render2D::EndScene() {
  flush();
}

void Render2D::Clear(float r, float g, float b, float a) {
  RenderCommand::SetClearColor(r, g, b, a);
  RenderCommand::Clear();
}

void Render2D::DrawQuad(float x, float y, float w, float h,
                        float r, float g, float b, float a)
{
  const float c[4] = { r,g,b,a };
  submitQuad(x, y, w, h, c, /*texSlot*/0, 0,0,1,1, 1.0f);
}

void Render2D::DrawQuad(float x, float y, float w, float h,
                        Ref<ITexture2D> texture,
                        float tr, float tg, float tb, float ta,
                        float u0, float v0, float u1, float v1,
                        float tiling)
{
  const float c[4] = { tr,tg,tb,ta };
  const int slot = getTextureSlot(texture);
  submitQuad(x, y, w, h, c, slot, u0, v0, u1, v1, tiling);
}

Render2D::Stats Render2D::GetStats() { return s_stats; }
void Render2D::ResetStats() { s_stats = {}; }

// ---------- Internals ----------

void Render2D::startBatch() {
  s_quadCount = 0;
  s_texCount  = 0;
  std::memset(s_texSlots, 0, sizeof(s_texSlots));
  s_texSlots[s_texCount++] = s_white; // slot 0 always white
}

int Render2D::getTextureSlot(const Ref<ITexture2D>& tex) {
  // Already in table?
  for (uint32_t i=0; i<s_texCount; ++i) {
    if (s_texSlots[i] == tex) return (int)i;
  }
  // Need new slot
  if (s_texCount >= MaxTexSlots) {
    flush();
  }
  s_texSlots[s_texCount] = tex;
  return (int)s_texCount++;
}

void Render2D::submitQuad(float x, float y, float w, float h,
                          const float color[4], int texSlot,
                          float u0, float v0, float u1, float v1,
                          float tiling)
{
  // If adding one more quad would exceed capacity, flush first.
  if (s_quadCount >= MaxQuads) {
    flush();
  }

  const size_t base = (size_t)s_quadCount * 4;
  // Paranoia guard (shouldn't trigger with fixed MaxVerts)
  if (base + 3 >= s_cpu.size()) {
    flush();
    if (s_cpu.size() < 4) s_cpu.resize(4);
  }

  const float x0 = x,    y0 = y;
  const float x1 = x + w, y1 = y + h;

  QuadVertex* v = &s_cpu[base];
  v[0] = { x0, y0, color[0],color[1],color[2],color[3], u0, v0, (float)texSlot, tiling };
  v[1] = { x0, y1, color[0],color[1],color[2],color[3], u0, v1, (float)texSlot, tiling };
  v[2] = { x1, y1, color[0],color[1],color[2],color[3], u1, v1, (float)texSlot, tiling };
  v[3] = { x1, y0, color[0],color[1],color[2],color[3], u1, v0, (float)texSlot, tiling };

  s_quadCount++;
  s_stats.quadCount++;
}

void Render2D::flush() {
  if (s_quadCount == 0) return;

  const uint32_t vertCount  = s_quadCount * 4;
  const uint32_t indexCount = s_quadCount * 6;

  // Upload only the used vertex range
  s_vbo->UpdateSubData(0, s_cpu.data(), sizeof(QuadVertex) * vertCount);

  // Bind textures for this batch
  for (uint32_t i=0; i<s_texCount; ++i) {
    s_texSlots[i]->Bind((int)i);
  }

  s_vao->Bind();
  
  s_shader->Bind();
  s_shader->SetMat4("uViewProj", s_viewProj);

  // Draw call
  RenderCommand::DrawIndexed(*s_vao, indexCount);
  s_stats.drawCalls++;

  s_vao->Unbind();

  // Reset for next batch
  startBatch();
}
