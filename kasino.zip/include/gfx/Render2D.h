#pragma once
#include <memory>
#include <vector>
#include <cstdint>
#include "core/Types.h"
#include "gfx/ITexture2D.h"
#include "gfx/IShader.h"
#include "gfx/IBuffer.h"
#include "gfx/IVertexArray.h"

class Camera2D;

// template<typename T> using Ref = std::shared_ptr<T>;

class Camera2D;

class Render2D {
public:
  // Build VAO/VBO/IBO, shader, and 1x1 white texture (idempotent).
  static bool Initialize();
  static void Shutdown();

  // Scene begin variants
  static void BeginScene(const glm::mat4& viewProj);
  static void BeginScene(const Camera2D& cam);

  // Flush any remaining batched geometry.
  static void EndScene();

  // Optional clear (you can also clear in your device)
  static void Clear(float r, float g, float b, float a);

  // Batched draws
  static void DrawQuad(float x, float y, float w, float h,
		       float r, float g, float b, float a);

  static void DrawQuad(float x, float y, float w, float h,
		       Ref<ITexture2D> texture,
		       float tintR=1, float tintG=1, float tintB=1, float tintA=1,
		       float u0=0, float v0=0, float u1=1, float v1=1,
		       float tiling=1.0f);

  struct Stats { uint32_t drawCalls=0, quadCount=0; };
  static Stats GetStats();
  static void  ResetStats();

private:
  struct QuadVertex {
    float x, y;        // position
    float r, g, b, a;  // color/tint
    float u, v;        // UV
    float texIndex;    // texture slot index (0..15)
    float tiling;      // UV tiling factor
  };

  static constexpr uint32_t MaxQuads    = 10'000;
  static constexpr uint32_t MaxVerts    = MaxQuads * 4;
  static constexpr uint32_t MaxIndices  = MaxQuads * 6;
  static constexpr uint32_t MaxTexSlots = 16;

private:
  static void startBatch();
  static void flush();
  static int  getTextureSlot(const Ref<ITexture2D>& tex);
  static void submitQuad(float x, float y, float w, float h,
			 const float color[4], int texSlot,
			 float u0, float v0, float u1, float v1,
			 float tiling);

private:
  // Static state (use Ref<> = shared_ptr)
  static Ref<IVertexArray> s_vao;
  static Ref<IBuffer>      s_vbo;   // dynamic vertex buffer
  static Ref<IBuffer>      s_ibo;   // static index buffer
  static Ref<IShader>      s_shader;
  static Ref<ITexture2D>   s_white;

  static std::vector<QuadVertex> s_cpu; // CPU-side staging for the batch
  static uint32_t s_quadCount;

  static Ref<ITexture2D> s_texSlots[MaxTexSlots]; // current batch's bound textures
  static uint32_t        s_texCount;

  static glm::mat4 s_viewProj;

  static Stats s_stats;
  static bool  s_ready;
};

