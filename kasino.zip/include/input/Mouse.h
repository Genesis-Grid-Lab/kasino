#pragma once

enum class MouseButton : unsigned char {
  Left = 0,
  Right = 1,
  Middle = 2,
  Button4 = 3,
  Button5 = 4
};

